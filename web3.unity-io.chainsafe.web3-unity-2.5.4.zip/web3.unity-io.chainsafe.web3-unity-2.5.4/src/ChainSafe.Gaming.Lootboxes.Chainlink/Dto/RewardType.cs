namespace ChainSafe.Gaming.Lootboxes.Chainlink
{
    public enum RewardType
    {
        Unset,
        Erc20,
        Erc721,
        Erc1155,
        Erc1155Nft,
    }
}