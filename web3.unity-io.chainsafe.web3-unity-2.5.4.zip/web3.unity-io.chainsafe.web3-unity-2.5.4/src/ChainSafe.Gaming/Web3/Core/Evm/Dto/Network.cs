namespace ChainSafe.Gaming.Evm.Network
{
    public class Network
    {
        public string Name { get; set; }

        public ulong ChainId { get; set; }
    }
}