namespace ChainSafe.Gaming.Web3.Core
{
    public interface IWeb3SubCategory
    {
        Web3 Web3 { get; }
    }
}