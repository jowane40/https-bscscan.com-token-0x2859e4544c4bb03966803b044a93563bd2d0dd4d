using ChainSafe.Gaming.Web3.Build;

namespace ChainSafe.Gaming.Web3
{
    public interface IWeb3BuildSubCategory
    {
        IWeb3ServiceCollection Services { get; }
    }
}