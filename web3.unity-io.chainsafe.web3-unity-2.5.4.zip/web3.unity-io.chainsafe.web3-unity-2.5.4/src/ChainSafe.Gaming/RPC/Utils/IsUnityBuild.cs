﻿#if Unity
namespace ChainSafe.Gaming.Evm.Utils
{
    /// <summary>
    /// Defines the <see cref="IsUnityBuild"/> class.
    /// </summary>
    public class IsUnityBuild
    {
    }
}
#endif
