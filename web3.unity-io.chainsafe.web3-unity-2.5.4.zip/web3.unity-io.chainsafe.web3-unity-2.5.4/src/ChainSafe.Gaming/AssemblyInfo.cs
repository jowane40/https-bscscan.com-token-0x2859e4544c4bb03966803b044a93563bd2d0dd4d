﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ChainSafe.Gaming.NetCore")]
[assembly: InternalsVisibleTo("ChainSafe.Gaming.Unity")]