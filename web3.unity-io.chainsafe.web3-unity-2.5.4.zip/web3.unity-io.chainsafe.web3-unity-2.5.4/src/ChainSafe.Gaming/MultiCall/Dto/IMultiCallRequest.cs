﻿using Nethereum.Contracts;
using Nethereum.Contracts.QueryHandlers.MultiCall;

namespace ChainSafe.Gaming.MultiCall.Dto
{
    public interface IMultiCallRequest : IMulticallInputOutput
    {
    }
}