const t=`<svg width="100%" height="100%" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect width="32" height="32" rx="10.3333" fill="#00FFFF"/>
<path d="M7.44031 24.5598H24.5597V16.8561H10.8642C8.97323 16.8561 7.44031 18.389 7.44031 20.28V24.5598Z" fill="#0B1821"/>
<path d="M24.5597 7.44043H7.44031V15.1442H21.1358C23.0268 15.1442 24.5597 13.6112 24.5597 11.7203V7.44043Z" fill="#0B1821"/>
</svg>
`;export{t as default};
