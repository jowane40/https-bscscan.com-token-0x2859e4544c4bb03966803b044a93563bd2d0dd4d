const t=`
  <svg width="100%" height="100%" viewBox="0 0 257 277" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="153.889" height="82.0741" fill="#0364FF" />
    <rect x="71.8135" width="82.0741" height="277" fill="#0364FF" />
    <path d="M215.443 82.0741C238.107 82.0741 256.48 63.7012 256.48 41.037C256.48 18.3729 238.107 0 215.443 0C192.779 0 174.406 18.3729 174.406 41.037C174.406 63.7012 192.779 82.0741 215.443 82.0741Z" fill="#0364FF" />
  </svg>
`;export{t as default};
