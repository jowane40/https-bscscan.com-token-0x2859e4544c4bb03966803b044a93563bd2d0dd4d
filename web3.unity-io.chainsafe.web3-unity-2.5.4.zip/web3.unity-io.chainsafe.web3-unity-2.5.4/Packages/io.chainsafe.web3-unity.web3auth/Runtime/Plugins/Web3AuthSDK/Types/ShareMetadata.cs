
public class ShareMetadata
{
    public string iv { get; set; }
    public string ephemPublicKey { get; set; }
    public string ciphertext { get; set; }
    public string mac { get; set; }
}
