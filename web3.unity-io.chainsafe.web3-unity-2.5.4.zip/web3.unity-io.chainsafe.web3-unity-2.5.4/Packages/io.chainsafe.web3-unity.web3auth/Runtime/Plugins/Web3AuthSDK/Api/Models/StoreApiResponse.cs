using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoreApiResponse
{
    public string message { get; set; }
    public bool success { get; set; }
}
