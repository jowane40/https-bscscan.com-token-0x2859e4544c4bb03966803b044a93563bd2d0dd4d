﻿namespace LootBoxes.Chainlink
{
    public static class Menues
    {
        public const string Root = "ChainSafe/Chainlink - LootBoxes/";
    }
}