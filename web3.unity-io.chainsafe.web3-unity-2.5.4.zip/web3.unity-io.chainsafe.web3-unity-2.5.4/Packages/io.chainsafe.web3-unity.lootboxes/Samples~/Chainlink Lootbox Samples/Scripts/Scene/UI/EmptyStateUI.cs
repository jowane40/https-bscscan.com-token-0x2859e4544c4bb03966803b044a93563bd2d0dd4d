﻿using UnityEngine;

namespace LootBoxes.Chainlink.Scene
{
    public class EmptyStateUI : MonoBehaviour
    {
    }
}