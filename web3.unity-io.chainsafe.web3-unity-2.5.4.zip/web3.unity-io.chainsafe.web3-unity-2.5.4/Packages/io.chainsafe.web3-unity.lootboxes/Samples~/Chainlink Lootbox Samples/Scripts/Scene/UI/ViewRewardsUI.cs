﻿using UnityEngine;
using UnityEngine.UI;

namespace LootBoxes.Chainlink.Scene
{
    public class ViewRewardsUI : MonoBehaviour
    {
        public Button PrevRewardButton;
        public Button NextRewardButton;
        public Button ContinueButton;
    }
}