﻿using UnityEngine;

namespace LootBoxes.Chainlink.Scene
{
    public class PromptClaimRewardsUI : MonoBehaviour
    {
    }
}