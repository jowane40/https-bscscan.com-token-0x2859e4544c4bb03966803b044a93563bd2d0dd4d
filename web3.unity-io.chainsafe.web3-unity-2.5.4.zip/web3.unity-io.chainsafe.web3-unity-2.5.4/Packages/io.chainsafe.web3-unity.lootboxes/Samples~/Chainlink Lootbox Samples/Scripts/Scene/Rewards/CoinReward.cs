﻿using TMPro;

namespace LootBoxes.Chainlink.Scene
{
    public class CoinReward : Reward
    {
        public TMP_Text SymbolLabel;
        public TMP_Text Amount;
    }
}