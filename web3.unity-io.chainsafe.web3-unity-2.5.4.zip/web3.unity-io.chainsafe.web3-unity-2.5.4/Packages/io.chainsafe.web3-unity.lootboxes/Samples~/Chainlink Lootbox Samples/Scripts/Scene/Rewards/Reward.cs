﻿using UnityEngine;

namespace LootBoxes.Chainlink.Scene
{
    public abstract class Reward : MonoBehaviour
    {
    }
}