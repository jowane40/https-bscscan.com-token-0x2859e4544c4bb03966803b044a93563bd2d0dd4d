﻿using UnityEngine;

namespace LootBoxes.Chainlink.Scene
{
    public class NftReward : Reward
    {
        public Renderer ImageRenderer;
    }
}